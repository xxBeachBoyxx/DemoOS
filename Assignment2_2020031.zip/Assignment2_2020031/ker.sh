#! usr/bin/bash

cd /home/apoorv/build/linux-6.0.9
sudo make
sudo make modules_install
